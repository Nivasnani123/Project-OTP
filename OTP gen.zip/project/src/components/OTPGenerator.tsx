import React, { useState, useEffect, useCallback } from 'react';
import { Copy, Clock, RefreshCw, History, Download, Settings, Shield } from 'lucide-react';

interface OTPEntry {
  id: string;
  code: string;
  timestamp: Date;
  type: 'TOTP' | 'HOTP' | 'Random';
  length: number;
}

const OTPGenerator: React.FC = () => {
  const [currentOTP, setCurrentOTP] = useState<string>('');
  const [otpLength, setOTPLength] = useState<number>(6);
  const [otpType, setOTPType] = useState<'TOTP' | 'HOTP' | 'Random'>('TOTP');
  const [timeRemaining, setTimeRemaining] = useState<number>(30);
  const [counter, setCounter] = useState<number>(0);
  const [history, setHistory] = useState<OTPEntry[]>([]);
  const [copied, setCopied] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const generateSecureRandom = (length: number): string => {
    const digits = '0123456789';
    let result = '';
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    
    for (let i = 0; i < length; i++) {
      result += digits[array[i] % 10];
    }
    return result;
  };

  const generateTOTP = useCallback((length: number): string => {
    const timeStep = 30;
    const currentTime = Math.floor(Date.now() / 1000);
    const timeCounter = Math.floor(currentTime / timeStep);
    
    // Simple TOTP-like generation for demo purposes
    const seed = timeCounter.toString() + 'secretkey';
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = ((hash << 5) - hash + seed.charCodeAt(i)) & 0xffffffff;
    }
    
    const otp = Math.abs(hash).toString().padStart(length, '0').slice(-length);
    return otp;
  }, []);

  const generateHOTP = useCallback((counter: number, length: number): string => {
    const seed = counter.toString() + 'secretkey';
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = ((hash << 5) - hash + seed.charCodeAt(i)) & 0xffffffff;
    }
    
    const otp = Math.abs(hash).toString().padStart(length, '0').slice(-length);
    return otp;
  }, []);

  const generateOTP = useCallback(async () => {
    setIsGenerating(true);
    
    // Add a small delay for better UX
    await new Promise(resolve => setTimeout(resolve, 300));
    
    let newOTP: string;
    
    switch (otpType) {
      case 'TOTP':
        newOTP = generateTOTP(otpLength);
        break;
      case 'HOTP':
        newOTP = generateHOTP(counter, otpLength);
        setCounter(prev => prev + 1);
        break;
      case 'Random':
        newOTP = generateSecureRandom(otpLength);
        break;
      default:
        newOTP = generateSecureRandom(otpLength);
    }
    
    setCurrentOTP(newOTP);
    
    const newEntry: OTPEntry = {
      id: Date.now().toString(),
      code: newOTP,
      timestamp: new Date(),
      type: otpType,
      length: otpLength
    };
    
    setHistory(prev => [newEntry, ...prev.slice(0, 9)]);
    setIsGenerating(false);
  }, [otpType, otpLength, counter, generateTOTP, generateHOTP]);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const exportHistory = () => {
    const dataStr = JSON.stringify(history, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `otp-history-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  // Timer for TOTP
  useEffect(() => {
    if (otpType === 'TOTP') {
      const interval = setInterval(() => {
        const now = Math.floor(Date.now() / 1000);
        const remaining = 30 - (now % 30);
        setTimeRemaining(remaining);
        
        if (remaining === 30) {
          generateOTP();
        }
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [otpType, generateOTP]);

  // Initial OTP generation
  useEffect(() => {
    generateOTP();
  }, []);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'TOTP': return 'text-blue-600 bg-blue-100';
      case 'HOTP': return 'text-purple-600 bg-purple-100';
      case 'Random': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">OTP Generator</h1>
          <p className="text-gray-300">Secure One-Time Password Generation</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main OTP Display */}
          <div className="lg:col-span-2">
            <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-8 shadow-2xl">
              <div className="text-center mb-8">
                <div className="relative">
                  <div className="text-6xl font-mono font-bold text-white tracking-wider mb-4 select-all">
                    {isGenerating ? (
                      <div className="flex items-center justify-center">
                        <RefreshCw className="w-12 h-12 animate-spin text-blue-400" />
                      </div>
                    ) : (
                      currentOTP || '------'
                    )}
                  </div>
                  
                  {otpType === 'TOTP' && (
                    <div className="flex items-center justify-center mb-4">
                      <div className="flex items-center bg-blue-500/20 rounded-full px-4 py-2">
                        <Clock className="w-4 h-4 text-blue-400 mr-2" />
                        <span className="text-blue-400 font-semibold">
                          {timeRemaining}s remaining
                        </span>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-center gap-4">
                    <button
                      onClick={() => copyToClipboard(currentOTP)}
                      className="flex items-center px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-full font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                    
                    <button
                      onClick={generateOTP}
                      disabled={isGenerating}
                      className="flex items-center px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-full font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg disabled:opacity-50"
                    >
                      <RefreshCw className={`w-4 h-4 mr-2 ${isGenerating ? 'animate-spin' : ''}`} />
                      Generate
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Settings Panel */}
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-6 shadow-2xl">
              <div className="flex items-center mb-4">
                <Settings className="w-5 h-5 text-white mr-2" />
                <h3 className="text-lg font-semibold text-white">Settings</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    OTP Type
                  </label>
                  <select
                    value={otpType}
                    onChange={(e) => setOTPType(e.target.value as 'TOTP' | 'HOTP' | 'Random')}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="TOTP" className="bg-gray-800">Time-based (TOTP)</option>
                    <option value="HOTP" className="bg-gray-800">Counter-based (HOTP)</option>
                    <option value="Random" className="bg-gray-800">Random</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    OTP Length: {otpLength}
                  </label>
                  <input
                    type="range"
                    min="4"
                    max="8"
                    value={otpLength}
                    onChange={(e) => setOTPLength(parseInt(e.target.value))}
                    className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>
                
                {otpType === 'HOTP' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Counter: {counter}
                    </label>
                    <button
                      onClick={() => setCounter(0)}
                      className="text-xs text-blue-400 hover:text-blue-300"
                    >
                      Reset Counter
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* History Panel */}
            <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <History className="w-5 h-5 text-white mr-2" />
                  <h3 className="text-lg font-semibold text-white">History</h3>
                </div>
                {history.length > 0 && (
                  <button
                    onClick={exportHistory}
                    className="p-2 text-gray-400 hover:text-white transition-colors"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                )}
              </div>
              
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {history.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-4">No history yet</p>
                ) : (
                  history.map((entry) => (
                    <div
                      key={entry.id}
                      className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                      onClick={() => copyToClipboard(entry.code)}
                    >
                      <div className="flex-1">
                        <div className="font-mono font-semibold text-white">
                          {entry.code}
                        </div>
                        <div className="text-xs text-gray-400">
                          {entry.timestamp.toLocaleTimeString()}
                        </div>
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-semibold ${getTypeColor(entry.type)}`}>
                        {entry.type}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OTPGenerator;