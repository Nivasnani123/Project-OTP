import React from 'react';
import OTPGenerator from './components/OTPGenerator';

function App() {
  return <OTPGenerator />;
}

export default App;