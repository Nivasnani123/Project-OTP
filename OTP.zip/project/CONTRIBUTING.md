# Contributing to OTP Generator

Thank you for considering contributing to the OTP Generator project! We welcome contributions from everyone.

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported in the [Issues](https://github.com/nivas/otp-generator/issues)
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce the bug
   - Expected vs actual behavior
   - Screenshots if applicable
   - Your environment details (OS, browser, etc.)

### Suggesting Features

1. Check existing issues for similar feature requests
2. Create a new issue with:
   - Clear title and description
   - Use case for the feature
   - Possible implementation approach

### Code Contributions

1. **Fork the repository**
   ```bash
   git clone https://github.com/nivas/otp-generator.git
   ```

2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow the existing code style
   - Add comments for complex logic
   - Update documentation if needed

4. **Test your changes**
   ```bash
   npm run dev
   npm run build
   ```

5. **Commit your changes**
   ```bash
   git commit -m "Add: your feature description"
   ```

6. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Create a Pull Request**
   - Provide a clear title and description
   - Reference any related issues
   - Include screenshots for UI changes

## Development Setup

1. **Prerequisites**
   - Node.js (v16 or higher)
   - npm or yarn

2. **Installation**
   ```bash
   git clone https://github.com/nivas/otp-generator.git
   cd otp-generator
   npm install
   ```

3. **Development**
   ```bash
   npm run dev
   ```

4. **Building**
   ```bash
   npm run build
   ```

## Code Style Guidelines

- Use TypeScript for type safety
- Follow React best practices
- Use functional components with hooks
- Keep components small and focused
- Use meaningful variable and function names
- Add comments for complex logic

## Commit Message Guidelines

Use clear and descriptive commit messages:

- `Add: new feature`
- `Fix: bug description`
- `Update: component/feature name`
- `Remove: deprecated code`
- `Refactor: code improvement`

## Pull Request Guidelines

- Keep PRs focused on a single feature or bug fix
- Include tests if applicable
- Update documentation as needed
- Ensure all checks pass
- Be responsive to feedback

## Questions?

If you have questions about contributing, feel free to:
- Open an issue for discussion
- Contact the maintainer: [@nivas](https://github.com/nivas)

Thank you for contributing! 🎉