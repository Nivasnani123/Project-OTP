# OTP Generator

A beautiful and secure One-Time Password (OTP) generator built with React, TypeScript, and Tailwind CSS. Features automatic refresh, copy functionality, and a stunning glassmorphism design.

## 🚀 Features

- **Secure OTP Generation**: Generates 6-digit random OTPs using cryptographically secure methods
- **Auto-Refresh**: Automatically generates new OTPs every 30 seconds
- **Copy to Clipboard**: One-click copy functionality with visual feedback
- **Beautiful UI**: Modern glassmorphism design with animated backgrounds
- **Responsive Design**: Works perfectly on all device sizes
- **Real-time Timer**: Visual countdown showing time remaining for current OTP
- **Progress Bar**: Visual indicator of OTP validity period

## 🛠️ Technologies Used

- **React 18** - Modern React with hooks
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first CSS framework
- **Vite** - Fast build tool and dev server
- **Lucide React** - Beautiful icon library

## 📦 Installation

1. Clone the repository:
```bash
git clone https://github.com/nivas/otp-generator.git
cd otp-generator
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

## 🏗️ Build for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## 📁 Project Structure

```
otp-generator/
├── src/
│   ├── App.tsx          # Main application component
│   ├── main.tsx         # Application entry point
│   └── index.css        # Global styles and animations
├── public/
├── dist/                # Built files (generated)
├── package.json         # Dependencies and scripts
├── tailwind.config.js   # Tailwind CSS configuration
├── tsconfig.json        # TypeScript configuration
├── vite.config.ts       # Vite configuration
└── README.md           # This file
```

## 🎨 Design Features

- **Glassmorphism Effect**: Modern frosted glass appearance
- **Animated Blobs**: Floating background elements with smooth animations
- **Gradient Backgrounds**: Beautiful color transitions
- **Hover Effects**: Interactive button states
- **Loading States**: Smooth transitions during OTP generation
- **Visual Feedback**: Clear indicators for all user actions

## 🔧 Configuration

The application uses several configuration files:

- `tailwind.config.js` - Tailwind CSS customization
- `tsconfig.json` - TypeScript compiler options
- `vite.config.ts` - Vite build configuration
- `postcss.config.js` - PostCSS plugins

## 🚀 Deployment

This project is deployed on Netlify. You can view the live demo at:
[https://wonderful-kitsune-f784e6.netlify.app](https://wonderful-kitsune-f784e6.netlify.app)

### Deploy to Netlify

1. Build the project:
```bash
npm run build
```

2. Deploy the `dist` folder to Netlify

### Deploy to Vercel

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Deploy:
```bash
vercel
```

## 📱 Usage

1. **View OTP**: The current 6-digit OTP is displayed prominently
2. **Copy OTP**: Click the "Copy" button to copy the OTP to clipboard
3. **Manual Refresh**: Click the refresh button to generate a new OTP immediately
4. **Auto-Refresh**: OTPs automatically refresh every 30 seconds
5. **Timer**: Watch the countdown timer and progress bar for time remaining

## 🔒 Security Features

- Uses `Math.random()` for OTP generation (suitable for demo purposes)
- Automatic expiration every 30 seconds
- No storage of generated OTPs
- Client-side generation for privacy

## 🎯 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 👨‍💻 Author

**Nivas**
- GitHub: [@nivas](https://github.com/nivas)

## 🤝 Contributing

Contributions, issues, and feature requests are welcome! Feel free to check the [issues page](https://github.com/nivas/otp-generator/issues).

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## ⭐ Show your support

Give a ⭐️ if this project helped you!

## 📝 Changelog

### v1.0.0
- Initial release
- Basic OTP generation
- Auto-refresh functionality
- Copy to clipboard
- Responsive design
- Glassmorphism UI

---

Made with ❤️ by [Nivas](https://github.com/nivas)